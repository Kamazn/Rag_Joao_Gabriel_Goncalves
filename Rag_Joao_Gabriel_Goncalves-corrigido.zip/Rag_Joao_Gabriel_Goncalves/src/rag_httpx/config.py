from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[2]

DATA_PATH = PROJECT_ROOT / "data"
HTTPX_REPOSITORY_PATH = DATA_PATH / "httpx"
DOCS_PATH = HTTPX_REPOSITORY_PATH / "docs"
CHROMA_PATH = DATA_PATH / "chroma"

# Versão exigida do httpx + o numero de markdowns esperado
HTTPX_COMMIT = "b5addb64f0161ff6bfe94c124ef76f6a1fba5254"
EXPECTED_MARKDOWN_FILES = 23

# Modelos que vao ser utilizados e idioma que a resposta vai sair
EMBEDDING_MODEL = "qwen3-embedding:4b"
GENERATION_MODEL = "qwen3.5:4b"
DEFAULT_RESPONSE_LANGUAGE = "pt-BR"

# Valores escolhidos depois de comparar tres configuracoes
CHUNK_SIZE_WORDS = 60
CHUNK_OVERLAP_WORDS = 10

DEFAULT_TOP_K = 3
MIN_TOP_K = 3
MAX_TOP_K = 5

# Similaridade minima pra um trecho ser considerado relevante.
# Nos testes manuais, perguntas fora do assunto ficaram entre 0.23 e 0.26
# e perguntas do assunto passaram de 0.80. Recalibre com evaluate_retrieval.py
MIN_SIMILARITY = 0.45

# Limita o tamanho da pergunta antes de gerar o embedding
MAX_QUERY_LENGTH = 500

# Resposta padrao quando nao existe informacao relevante na base.
# Ela nunca vem acompanhada de fontes ou trechos
NOT_FOUND_MESSAGE = (
    "Não encontrei essa informação na documentação do HTTPX."
)

CHROMA_COLLECTION_NAME = "httpx_docs"
